using ReactiveDomain.Messaging;

namespace RD.Core.Services.Project {
    public class NewProjectRequest : Command { 

    }
}