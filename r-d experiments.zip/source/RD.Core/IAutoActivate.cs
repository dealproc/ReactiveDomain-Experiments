namespace RD.Core {
    public interface IAutoActivate { }
}